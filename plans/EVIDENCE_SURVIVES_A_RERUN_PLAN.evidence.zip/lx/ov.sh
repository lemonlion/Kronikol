#!/bin/sh
# overlayfs checks for EVIDENCE_SURVIVES_A_RERUN_PLAN.md. Hard-coded paths only, and set -u: an unset
# variable must stop the script, never reach an rm.
set -eu

mountpoint -q /var/tmp/kronikol-ov/merged && sudo umount /var/tmp/kronikol-ov/merged
sudo rm -rf /var/tmp/kronikol-ov
mkdir -p /var/tmp/kronikol-ov/lower/prev /var/tmp/kronikol-ov/lower/olddir /var/tmp/kronikol-ov/upper /var/tmp/kronikol-ov/work /var/tmp/kronikol-ov/merged

# A "previous run" that lives in the LOWER layer: 402 files, the report 8 MB.
i=0
while [ "$i" -lt 400 ]; do
  head -c 20000 /dev/zero > "/var/tmp/kronikol-ov/lower/prev/file$(printf '%03d' "$i").html"
  i=$((i + 1))
done
head -c 8000000 /dev/zero > /var/tmp/kronikol-ov/lower/prev/TestRunReport.json
echo '{}' > /var/tmp/kronikol-ov/lower/prev/Run.json
echo x > /var/tmp/kronikol-ov/lower/olddir/f

sudo mount -t overlay overlay -o lowerdir=/var/tmp/kronikol-ov/lower,upperdir=/var/tmp/kronikol-ov/upper,workdir=/var/tmp/kronikol-ov/work /var/tmp/kronikol-ov/merged
sudo chown user /var/tmp/kronikol-ov/merged
echo "--- mounted as: $(stat -f -c %T /var/tmp/kronikol-ov/merged) ---"

/var/tmp/lx timing /var/tmp/kronikol-ov/merged/t

echo "--- a rotation of a run whose files are all in the lower layer ---"
/var/tmp/lx child /var/tmp/kronikol-ov/merged/prev
echo "top-level files left: $(find /var/tmp/kronikol-ov/merged/prev -maxdepth 1 -type f | wc -l)"
echo "published under runs/x: $(find /var/tmp/kronikol-ov/merged/prev/runs/x -type f | wc -l)"
echo "report size after the move: $(stat -c %s /var/tmp/kronikol-ov/merged/prev/runs/x/TestRunReport.json)"
echo "staging directories left: $(find /var/tmp/kronikol-ov/merged/prev/runs -maxdepth 1 -name '.incoming-*' | wc -l)"

echo "--- a DIRECTORY from the lower layer renamed (the rotation never does this) ---"
if mv /var/tmp/kronikol-ov/merged/olddir /var/tmp/kronikol-ov/merged/olddir2 2>/var/tmp/kronikol-ov/mv.err; then
  echo "mv of a lower-layer directory: ok"
else
  echo "mv of a lower-layer directory: FAILED - $(cat /var/tmp/kronikol-ov/mv.err)"
fi

echo "--- the kill harness on overlayfs ---"
/var/tmp/lx kill /var/tmp/kronikol-ov/merged/k 200 8

sudo umount /var/tmp/kronikol-ov/merged
sudo rm -rf /var/tmp/kronikol-ov
rm -f /var/tmp/lx
echo "--- cleaned up ---"
