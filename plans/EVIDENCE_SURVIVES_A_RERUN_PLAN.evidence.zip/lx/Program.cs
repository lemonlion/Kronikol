using System.Diagnostics;
using System.Runtime.InteropServices;

// EVIDENCE_SURVIVES_A_RERUN_PLAN.md - the S4 file-system claims, on whatever OS and file system this runs on.
//   lx timing <dir>        a 100 MB File.Move and a 402-file Directory.Move inside <dir>
//   lx held <dir>          what a reader holding the report blocks: today's overwrite, a move, an exclusive open
//   lx names               F7: what the repo's sanitising idiom does to a run id here
//   lx kill <work> <n>     the killed-rotation harness of §11.4 row 4
//   lx child <root>        (internal) one staged rotation
const char Lf = (char)10;
var mode = args.Length > 0 ? args[0] : "";
Console.WriteLine($"# {RuntimeInformation.OSDescription} · {RuntimeInformation.FrameworkDescription} · {mode}");

switch (mode)
{
    case "timing": Timing(args[1]); return 0;
    case "held": Held(args[1]); return 0;
    case "names": Names(); return 0;
    case "child": Child(args[1]); return 0;
    case "kill": Kill(args[1], int.Parse(args[2]), args.Length > 3 ? double.Parse(args[3]) : 60); return 0;
    default: Console.Error.WriteLine("modes: timing held names kill"); return 2;
}

static void Timing(string dir)
{
    Directory.CreateDirectory(dir);
    var big = Path.Combine(dir, "big.json");
    File.WriteAllBytes(big, new byte[100_000_000]);
    Directory.CreateDirectory(Path.Combine(dir, "runs", ".incoming-x"));
    var watch = Stopwatch.StartNew();
    File.Move(big, Path.Combine(dir, "runs", ".incoming-x", "big.json"));
    Console.WriteLine($"File.Move of 100 MB inside one directory tree: {watch.Elapsed.TotalMilliseconds:0.00} ms");
    for (var i = 0; i < 401; i++) File.WriteAllBytes(Path.Combine(dir, "runs", ".incoming-x", $"f{i:D3}.html"), new byte[20_000]);
    watch.Restart();
    Directory.Move(Path.Combine(dir, "runs", ".incoming-x"), Path.Combine(dir, "runs", "x"));
    Console.WriteLine($"Directory.Move publishing 402 files: {watch.Elapsed.TotalMilliseconds:0.00} ms");
    Directory.Delete(dir, true);
}

static void Held(string dir)
{
    Directory.CreateDirectory(dir);
    string Try(string what, Action action)
    {
        try { action(); return $"{what}: succeeds"; }
        catch (Exception e) { return $"{what}: {e.GetType().Name} - {e.Message.Split(Lf)[0]}"; }
    }

    foreach (var (label, open) in new (string, Func<string, FileStream>)[]
             {
                 ("File.OpenRead (what kronikol query does today)", p => File.OpenRead(p)),
                 ("FileShare.ReadWrite | FileShare.Delete (the S0 change)", p => new FileStream(p, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
             })
    {
        Console.WriteLine($"reader: {label}");
        var path = Path.Combine(dir, "TestRunReport.json");
        File.WriteAllText(path, "{\"first\":true}");
        using (var reader = open(path))
        {
            Console.WriteLine("  " + Try("File.WriteAllText over it (today's in-place overwrite)", () => File.WriteAllText(path, "{\"second\":true}")));
            Console.WriteLine("  " + Try("FileStream(Create, Write, FileShare.None) over it", () => { using var s = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None); }));
            Console.WriteLine("  " + Try("File.Move of it (the rotation)", () => File.Move(path, Path.Combine(dir, "moved.json"), overwrite: true)));
            // What the reader sees afterwards: the bytes of the file it opened, or of its replacement?
            Console.WriteLine("  " + Try("a new report written at the path afterwards", () => File.WriteAllText(path, "{\"third\":true,\"longer\":\"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\"}")));
            reader.Seek(0, SeekOrigin.Begin);
            var text = new StreamReader(reader, leaveOpen: true).ReadToEnd();
            Console.WriteLine($"  the open reader, re-read from 0: {text}");
            Console.WriteLine($"  a FRESH open of the same path (what PayloadReader does per payload): {Try("read", () => Console.Write(""))} -> {(File.Exists(path) ? File.ReadAllText(path) : "(no file at the path)")}");
        }
        foreach (var f in Directory.GetFiles(dir)) File.Delete(f);
    }
    Directory.Delete(dir, true);
}

static void Names()
{
    var invalid = Path.GetInvalidFileNameChars();
    Console.WriteLine($"Path.GetInvalidFileNameChars(): {invalid.Length} characters");
    foreach (var id in new[] { "local:20260918T101611Z:ab12cd34", "gh:18273645:1", "ado:5512:1", "custom/../..\\evil:*?id" })
    {
        var idiom = new string(id.Select(c => invalid.Contains(c) ? '_' : c).ToArray());
        var plan = new string(id.Select(c => c is >= 'A' and <= 'Z' or >= 'a' and <= 'z' or >= '0' and <= '9' or '.' or '_' or '-' ? c : '_').ToArray());
        Console.WriteLine($"  {id,-34} repo idiom -> {idiom,-34} plan's DirectoryName -> {plan}");
    }
}

static void Child(string root)
{
    var staging = Path.Combine(root, "runs", ".incoming-x");
    Directory.CreateDirectory(staging);
    File.WriteAllText(root + ".started", "");
    var files = Directory.GetFiles(root).Select(Path.GetFileName).OrderBy(f => f == "TestRunReport.json" ? 0 : f == "Run.json" ? 2 : 1).ToList();
    foreach (var f in files) File.Move(Path.Combine(root, f!), Path.Combine(staging, f!));
    Directory.Move(staging, Path.Combine(root, "runs", "x"));
}

static void Kill(string work, int n, double windowMs)
{
    var self = Environment.ProcessPath!;
    var tally = new SortedDictionary<string, int>();
    var random = new Random(7);
    var names = Enumerable.Range(0, 400).Select(i => $"file{i:D3}.html").Append("TestRunReport.json").Append("Run.json").ToList();
    Directory.CreateDirectory(work);
    for (var i = 0; i < n; i++)
    {
        var root = Path.Combine(work, "r" + i);
        Directory.CreateDirectory(root);
        foreach (var name in names) File.WriteAllBytes(Path.Combine(root, name), new byte[name == "TestRunReport.json" ? 8_000_000 : 20_000]);
        var p = Process.Start(new ProcessStartInfo(self, $"child \"{root}\"") { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true })!;
        while (!File.Exists(root + ".started") && !p.HasExited) Thread.Sleep(0);
        var spin = Stopwatch.StartNew();
        var until = random.NextDouble() * windowMs;
        while (spin.Elapsed.TotalMilliseconds < until) { }
        var killed = false;
        try { if (!p.HasExited) { p.Kill(); killed = true; } } catch { }
        p.WaitForExit();
        var top = names.Count(f => File.Exists(Path.Combine(root, f)));
        var staged = Directory.Exists(Path.Combine(root, "runs", ".incoming-x")) ? names.Count(f => File.Exists(Path.Combine(root, "runs", ".incoming-x", f))) : -1;
        var published = Directory.Exists(Path.Combine(root, "runs", "x")) ? names.Count(f => File.Exists(Path.Combine(root, "runs", "x", f))) : -1;
        var bad = names.Count(f =>
        {
            var copies = new[] { Path.Combine(root, f), Path.Combine(root, "runs", ".incoming-x", f), Path.Combine(root, "runs", "x", f) }.Where(File.Exists).ToList();
            return copies.Count != 1 || new FileInfo(copies[0]).Length != (f == "TestRunReport.json" ? 8_000_000 : 20_000);
        });
        var state = !killed ? "finished" : staged == -1 && published == -1 ? "killed-before-start" : published >= 0 ? $"killed-after-publish({published})" : top == 0 ? "killed-all-staged-unpublished" : "killed-mid-staging";
        var jsonNotFirst = staged > 0 && !File.Exists(Path.Combine(root, "runs", ".incoming-x", "TestRunReport.json"));
        var key = state + (bad > 0 ? $" BAD={bad}" : "") + (jsonNotFirst ? " JSON-NOT-FIRST" : "")
                  + (state == "killed-mid-staging" && !File.Exists(Path.Combine(root, "Run.json")) ? " RUNJSON-GONE" : "");
        tally[key] = tally.GetValueOrDefault(key) + 1;
        Directory.Delete(root, true);
        File.Delete(root + ".started");
    }
    foreach (var (k, v) in tally) Console.WriteLine($"{v,5}  {k}");
}
