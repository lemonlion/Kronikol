using System.Collections.Concurrent;
// S4's collector: a mutable object reached through an AsyncLocal, added to from Parallel.Invoke workers,
// from a Task inside one, and from a dedicated thread. Does the parent see every add?
var collector = new AsyncLocal<ConcurrentBag<string>?>();
collector.Value = new ConcurrentBag<string>();
Parallel.Invoke(
    () => collector.Value!.Add("worker-1"),
    () => collector.Value!.Add("worker-2"),
    () => Task.Run(() => collector.Value!.Add("task-inside-worker")).Wait(),
    () => { var t = new Thread(() => collector.Value!.Add("thread-inside-worker")); t.Start(); t.Join(); });
Console.WriteLine($"seen by the parent: {collector.Value!.Count} of 4 -> {string.Join(", ", collector.Value.OrderBy(x => x))}");
// And a scope opened INSIDE a worker must not leak out to the parent or to a sibling.
Parallel.Invoke(() => { collector.Value = new ConcurrentBag<string>(["inner"]); }, () => Thread.Sleep(50));
Console.WriteLine($"after a worker replaced the value, the parent still holds its own: {collector.Value!.Count} item(s)");
