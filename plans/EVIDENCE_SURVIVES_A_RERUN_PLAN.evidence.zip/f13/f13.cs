#:project C:/Users/cex/AppData/Local/Temp/claude/c--Code-BreakfastProvider/00a6c21d-1c0c-4010-abce-7a09ddaaa9a0/scratchpad/kwt-ev/src/Kronikol/Kronikol.csproj
// F13 follow-up: what does the analyzer SAY about a retried scenario, in each representation the
// CI ledger could hold it in?  (i) today's fold of both attempts as shards  (ii) one position, the
// last attempt's result, attempts = 2  (iii) what CI records today: the retry's fragment alone.
using System.Text;
using Kronikol.History;

var a1 = HistoryFragment.Parse(File.ReadAllText(args[0]));   // attempt 1: 13 scenarios, 1 failed
var a2 = HistoryFragment.Parse(File.ReadAllText(args[1]));   // attempt 2: the failed one, passed

var allPassed = new string('P', a1.Roster.Count);
HistoryRun Green(int n) => a1.Run with
{
    Id = $"gh:{n}:1",
    At = new DateTimeOffset(2026, 9, 1, 10, 0, 0, TimeSpan.Zero).AddDays(n - 770),
    Results = allPassed,
    Errors = null,
    ErrorText = new Dictionary<string, string>(),
    Partial = false
};

var folded = HistoryFold.Fold([a1, a2]).Single();
var foldedRun = folded.Run with { At = new DateTimeOffset(2026, 9, 8, 10, 0, 0, TimeSpan.Zero), Partial = false };

// (ii) the retry as an attempt: attempt 1's line, the retried position passed on attempt 2.
var retriedAt = a1.Roster.IndexOf(a2.Roster.Ids[0], 0);
var asAttempt = a1.Run with
{
    At = foldedRun.At,
    Partial = false,
    Results = allPassed,
    Attempts = new string('-', retriedAt) + "2" + new string('-', a1.Roster.Count - retriedAt - 1)
};

// (iii) what `history record` stores on CI today: only the retry's fragment survives.
var retryOnly = a2.Run with { At = foldedRun.At };

Report("(i) both attempts folded as shards — this plan's F13 consequence 2", folded.Roster, foldedRun, folded.Shapes);
Report("(ii) one position, last attempt wins, attempts = 2", a1.Roster, asAttempt, a1.Shapes);
Report("(iii) today on CI: the retry's fragment alone", a2.Roster, retryOnly, a2.Shapes);

// (iv) the prototype: HistoryFold.Attempts over the two REAL fragments, oldest first.
var overlaid = HistoryFold.Attempts([a1, a2]);
Console.WriteLine();
Console.WriteLine($"overlay of the real fragments: roster {overlaid.Roster.Count}, results {overlaid.Run.Results}, attempts {overlaid.Run.Attempts}, error at the retried position: {overlaid.Run.ErrorAt(retriedAt)}");
Console.WriteLine($"  call lines at the retried position: {string.Join(" | ", overlaid.Run.CallSetAt(retriedAt)!.Select(i => overlaid.Shapes!.At(i)))}");
Report("(iv) HistoryFold.Attempts([attempt 1, attempt 2]) - the prototype", overlaid.Roster, overlaid.Run with { At = foldedRun.At, Partial = false }, overlaid.Shapes);

void Report(string title, HistoryRoster roster, HistoryRun retried, HistoryShapes? shapes)
{
    Console.WriteLine();
    Console.WriteLine("=== " + title);
    var text = new StringBuilder();
    text.Append(HistoryJson.HeaderLine("probe")).Append('\n');
    text.Append(HistoryJson.RosterLine(a1.Roster)).Append('\n');
    if (roster.Hash != a1.Roster.Hash) text.Append(HistoryJson.RosterLine(roster)).Append('\n');
    if (a1.Shapes is { } s1) text.Append(HistoryJson.ShapesLine(s1)).Append('\n');
    if (shapes is { } s2 && s2.Hash != a1.Shapes?.Hash) text.Append(HistoryJson.ShapesLine(s2)).Append('\n');
    for (var n = 770; n <= 776; n++) text.Append(HistoryJson.RunLine(Green(n))).Append('\n');
    text.Append(HistoryJson.RunLine(retried)).Append('\n');
    var next = Green(778) with { At = retried.At.AddDays(1) };
    var after = Green(779) with { At = retried.At.AddDays(2) };
    text.Append(HistoryJson.RunLine(next)).Append('\n');
    text.Append(HistoryJson.RunLine(after)).Append('\n');

    var ledger = HistoryLedgerReader.Parse(text.ToString(), 0).Ledger!;
    // Until F4 is fixed the analyzer takes every other run as prior, so each reading gets a ledger
    // that ends at the run being read.
    Show("the retried run      ", Cut(text.ToString(), retried.Id), roster, retried, shapes);
    Show("the next run         ", Cut(text.ToString(), next.Id), a1.Roster, next, a1.Shapes);
    Show("the run after that   ", Cut(text.ToString(), after.Id), a1.Roster, after, a1.Shapes);
}

static HistoryLedger Cut(string text, string lastId)
{
    var kept = new StringBuilder();
    foreach (var line in text.Split('\n', StringSplitOptions.RemoveEmptyEntries))
    {
        kept.Append(line).Append('\n');
        if (line.Contains($"\"id\":\"{lastId}\"", StringComparison.Ordinal)) break;
    }
    return HistoryLedgerReader.Parse(kept.ToString(), 0).Ledger!;
}

static void Show(string label, HistoryLedger ledger, HistoryRoster roster, HistoryRun current, HistoryShapes? shapes)
{
    var verdicts = HistoryAnalyzer.Analyse(ledger, roster, current, new HistoryAnalysisOptions(), shapes: shapes);
    Console.WriteLine($"  {label} {current.Id}  roster {roster.Count}  partial={verdicts.Partial}  results {current.Results}  attempts {current.Attempts}");
    foreach (var s in verdicts.Scenarios.Where(s => s.Primary != HistoryVerdictKind.Stable))
        Console.WriteLine($"      {s.VerdictNames,-22} slot {s.Slot}  {s.Name}  [{s.Series}]  — {s.Evidence}");
    foreach (var a in verdicts.Absent)
        Console.WriteLine($"      ABSENT                 {a.Name}  (last in {a.LastRunId})");
    if (!verdicts.HasAnything) Console.WriteLine("      (all stable, nothing absent)");
}
