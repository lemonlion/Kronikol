#:project C:/Users/cex/AppData/Local/Temp/claude/c--Code-BreakfastProvider/00a6c21d-1c0c-4010-abce-7a09ddaaa9a0/scratchpad/kwt-ev/src/Kronikol/Kronikol.csproj
// Replays a real ledger run by run. With the F4 cut in the analyzer each run can be read IN PLACE,
// against the whole ledger; the earlier replay (plan §5.2) had to truncate the ledger by hand before
// every reading. Both are done here and compared: if the cut is right they agree on every verdict.
using System.Text;
using Kronikol.History;

var text = File.ReadAllText(args[0]);
var whole = HistoryLedgerReader.Parse(text, 0).Ledger!;
var lines = text.Split('\n', StringSplitOptions.RemoveEmptyEntries);

var runs = 0; var disagreements = 0; var behaviourChanged = 0;
var longNamed = 0; var longNamedScenarios = new HashSet<string>(); var maxNamed = 0;
var evidenceOver180 = 0; var evidenceOver400 = 0; var nonStable = 0; var maxEvidence = 0;
var options = new HistoryAnalysisOptions();

// The hand-cut ledger for run k is every line up to and including that run's line.
var prefix = new StringBuilder();
foreach (var line in lines)
{
    prefix.Append(line).Append('\n');
    var (kind, id, suite, suiteIsNull) = HistoryJson.Peek(line);
    if (kind != HistoryLineKind.Run || id is null) continue;

    var suiteKey = suiteIsNull ? null : suite;
    var current = whole.Runs(suiteKey).First(r => r.Id == id);
    var roster = whole.Roster(current.RosterHash);
    if (roster is null) continue;
    var shapes = current.ShapesHash is { } hash ? whole.Shapes(hash) : null;
    runs++;

    var inPlace = HistoryAnalyzer.Analyse(whole, roster, current, options, shapes: shapes);
    var cut = HistoryLedgerReader.Parse(prefix.ToString(), 0).Ledger!;
    var byHand = HistoryAnalyzer.Analyse(cut, roster, current, options, shapes: shapes);

    if (inPlace.RunsRecorded != byHand.RunsRecorded || inPlace.Absent.Count != byHand.Absent.Count
        || !inPlace.Scenarios.Select(s => s.VerdictNames + "|" + s.Evidence).SequenceEqual(byHand.Scenarios.Select(s => s.VerdictNames + "|" + s.Evidence)))
        disagreements++;

    foreach (var s in inPlace.Scenarios)
    {
        if (s.Has(HistoryVerdictKind.BehaviourChanged)) behaviourChanged++;
        if (s.Primary != HistoryVerdictKind.Stable)
        {
            nonStable++;
            if (s.Evidence.Length > 180) evidenceOver180++;
            if (s.Evidence.Length > 400) evidenceOver400++;
            maxEvidence = Math.Max(maxEvidence, s.Evidence.Length);
        }
        var named = Math.Max(s.NewCalls.Count, s.GoneCalls.Count);
        if (named > 3) { longNamed++; longNamedScenarios.Add(current.Suite + "|" + s.StableId); maxNamed = Math.Max(maxNamed, named); }
    }
}

Console.WriteLine($"{runs} runs replayed, {whole.Suites.Count()} suites");
Console.WriteLine($"in-place (F4 cut) vs hand-cut ledger: {disagreements} run(s) disagree");
Console.WriteLine($"behaviour-changed verdicts: {behaviourChanged}");
Console.WriteLine($"scenario readings with a verdict other than stable: {nonStable}");
Console.WriteLine($"  evidence longer than 180 chars (the run view's cut): {evidenceOver180}");
Console.WriteLine($"  evidence longer than 400 chars (the scenario view's cut): {evidenceOver400}; longest {maxEvidence}");
Console.WriteLine($"readings whose new/gone calls number more than the 3 the evidence names: {longNamed}, over {longNamedScenarios.Count} scenario(s); most calls {maxNamed}");
