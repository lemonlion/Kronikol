# Evidence for EVIDENCE_SURVIVES_A_RERUN_PLAN.md §11.5 (2026-09-19)

The harnesses behind the RUN claims of that round. They were run against a detached `git worktree` of
Kronikol `125a32cc` (3.22.0) with `EVIDENCE_SURVIVES_A_RERUN_PLAN.prototype.patch` applied, never the
working tree. The worktree is gone; to run one again, make a new one, apply the patch, and point the
first line of the `.cs` file (`#:project …/src/Kronikol/Kronikol.csproj`, Windows-style path) at it.

    git -C C:\Code\Kronikol worktree add --detach <scratch>\kwt HEAD
    git -C <scratch>\kwt apply C:\Code\Kronikol\plans\EVIDENCE_SURVIVES_A_RERUN_PLAN.prototype.patch
    dotnet run -c Release <harness>.cs -- <args>

Unit tests, directly (a bare exe does not get the runsettings variable, and one history test assumes it):

    $env:KRONIKOL_HISTORY='off'
    tests\Kronikol.Tests\bin\Debug\net10.0\Kronikol.Tests.exe -class Kronikol.Tests.History.HistoryAnalyzerTests -noLogo

| File | Plan row | What it shows | Arguments |
|---|---|---|---|
| `f13/f13.cs` | §11.5 row 1, §6.3 (F15) | What the analyzer says about a retried scenario in four representations: folded as shards (phantom `new`, then ABSENT), one position with `attempts` = 2 (`flaky … passed on retry 2`), the retry's fragment alone (today on CI), and `HistoryFold.Attempts` over the real fragments. Needs the patch for the last one | `frags/a1/History.run.json frags/a2/History.run.json` |
| `frags/a1`, `frags/a2` | same | The two fragments the MTP retry extension really wrote (TUnit example, fail-once test, `GITHUB_RUN_ID=777`): attempt 1 = 13 scenarios, 1 failed; attempt 2 = the failed one, passed | — |
| `replay/replay.cs` | §11.5 rows 3 and 8, §3.2, §4.2 | Every run of a ledger read IN PLACE (needs the F4 cut, i.e. the patch) against the same run read over a ledger truncated by hand after it: 394 runs, 0 disagreements, 712 behaviour-changed; evidence lengths against the 180 and 400 cuts; new/gone calls against the 3 that evidence names | BreakfastProvider's CI ledger: `git -C C:\Code\BreakfastProvider show origin/kronikol-history:<path to history.jsonl>` |
| `perf/gen.py`, `perf/perf.cs` | §11.5 row 7 (#91) | `Analyse` at 1,250 / 2,500 / 5,000 / 10,000 scenarios x 50 runs, and the same 250,000 `IndexOf` calls timed alone. `HISTORY_ANALYZER_COST_PLAN.md` owns this | `python gen.py 5000 big-5000.jsonl`, then the `.jsonl` files |
| `lx/` | §11.5 rows 5 and 6, §6.2 | One program, four modes: `names` (F7: `Path.GetInvalidFileNameChars()` per OS), `held <dir>` (what a reader holding the report blocks, and what its open handle reads after an in-place overwrite and after a move), `timing <dir>` (100 MB `File.Move`, 402-file `Directory.Move`), `kill <work> <n> <windowMs>` (the killed-rotation harness). `dotnet publish -c Release -r linux-x64 -o out-linux` gives a self-contained binary that runs in a WSL distro with no dotnet | see `Program.cs` header |
| `lx/ov.sh` | §11.5 row 6 | The overlayfs run: mounts an overlay under `/var/tmp/kronikol-ov`, rotates a run whose files are all in the LOWER layer, runs the kill harness on the merged directory, cleans up. Literal paths and `set -eu` on purpose — see the plan's note on `wsl.exe -- sh -c` | run inside the distro after copying `out-linux/lx` to `/var/tmp/lx` |
| `al/al.cs` | §11.5 row 9, §11.1b | The S4 collector pattern: a `ConcurrentBag` behind an `AsyncLocal`, added to from `Parallel.Invoke` workers, a `Task` and a `Thread` inside one — 4 of 4 reach the parent | — |
| `results.txt` | all | The output of each run as it was read | — |

Not in here, because it is reproducible or large: the BreakfastProvider CI ledger (4.5 MB), the generated
perf ledgers (4–31 MB), the published `lx` binaries (70 MB).
