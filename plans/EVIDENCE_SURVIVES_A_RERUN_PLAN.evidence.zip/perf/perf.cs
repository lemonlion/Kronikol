#:project C:/Users/cex/AppData/Local/Temp/claude/c--Code-BreakfastProvider/00a6c21d-1c0c-4010-abce-7a09ddaaa9a0/scratchpad/kwt-ev/src/Kronikol/Kronikol.csproj
// Issue #91: how does HistoryAnalyzer.Analyse grow with scenario count, and where does the time go?
using System.Diagnostics;
using Kronikol.History;

foreach (var path in args)
{
    var read = HistoryLedgerReader.Read(path, 50);
    var ledger = read.Ledger!;
    var current = ledger.Runs("Big").Last();
    var roster = ledger.Roster(current.RosterHash)!;

    var best = long.MaxValue;
    for (var i = 0; i < 3; i++)
    {
        var watch = Stopwatch.StartNew();
        HistoryAnalyzer.Analyse(ledger, roster, current, new HistoryAnalysisOptions());
        best = Math.Min(best, watch.ElapsedMilliseconds);
    }

    // The suspect on its own: one IndexOf per scenario per prior run, exactly as AnalyseScenario makes them.
    var prior = ledger.Runs("Big").Where(r => r.Id != current.Id).TakeLast(50).Select(r => ledger.Roster(r.RosterHash)!).ToArray();
    var lookups = Stopwatch.StartNew();
    long found = 0;
    for (var s = 0; s < roster.Count; s++)
        foreach (var priorRoster in prior)
            if (priorRoster.IndexOf(roster.Ids[s], roster.Slots[s]) >= 0) found++;
    lookups.Stop();

    Console.WriteLine($"{roster.Count,6} scenarios x {prior.Length} runs   analyse {best,6} ms   IndexOf alone {lookups.ElapsedMilliseconds,6} ms   ({found} lookups)");
}
