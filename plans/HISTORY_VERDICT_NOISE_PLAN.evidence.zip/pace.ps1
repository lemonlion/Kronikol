param([string]$Ledger)

function Median([double[]]$v) {
    if ($v.Count -eq 0) { return $null }
    $s = $v | Sort-Object
    $n = $s.Count
    if ($n % 2 -eq 1) { return [double]$s[($n - 1) / 2] }
    return ([double]$s[$n / 2 - 1] + [double]$s[$n / 2]) / 2.0
}
function Pct([double[]]$v, [double]$p) {
    $s = $v | Sort-Object
    $rank = [math]::Ceiling($p * $s.Count)
    return $s[[math]::Max(0, [math]::Min($s.Count - 1, $rank - 1))]
}

$rosters = @{}
$runsBySuite = @{}
foreach ($line in Get-Content $Ledger) {
    if ($line -match '^\{"t":"roster"') {
        $o = $line | ConvertFrom-Json
        $rosters[$o.hash] = $o.ids
    }
    elseif ($line -match '^\{"t":"run"') {
        $o = $line | ConvertFrom-Json
        $key = "$($o.suite)|$($o.branch)"
        if (-not $runsBySuite.ContainsKey($key)) { $runsBySuite[$key] = New-Object System.Collections.ArrayList }
        [void]$runsBySuite[$key].Add($o)
    }
}

$all = New-Object System.Collections.ArrayList
foreach ($key in $runsBySuite.Keys) {
    $runs = $runsBySuite[$key]
    for ($r = 0; $r -lt $runs.Count; $r++) {
        $run = $runs[$r]
        if ($null -eq $run.durations) { continue }
        $ids = $rosters[$run.roster]
        if ($null -eq $ids) { continue }
        $from = [math]::Max(0, $r - 50)
        $prior = @()
        for ($q = $from; $q -lt $r; $q++) { if ($runs[$q].partial -ne $true -and $null -ne $runs[$q].durations -and $rosters.ContainsKey($runs[$q].roster)) { $prior += , $runs[$q] } }
        if ($prior.Count -lt 5) { continue }

        # A: run median against the median of prior full runs' medians
        $speed = Median ([double[]]@($run.durations | Where-Object { $null -ne $_ }))
        $priorSpeeds = @($prior | ForEach-Object { Median ([double[]]@($_.durations | Where-Object { $null -ne $_ })) })
        $paceA = $speed / (Median ([double[]]$priorSpeeds))

        # B: median over scenarios of (this reading / the scenario's own median over prior full runs)
        $byId = @{}
        foreach ($p in $prior) {
            $pids = $rosters[$p.roster]
            for ($i = 0; $i -lt $pids.Count; $i++) {
                $d = $p.durations[$i]
                if ($null -eq $d) { continue }
                if (-not $byId.ContainsKey($pids[$i])) { $byId[$pids[$i]] = New-Object System.Collections.Generic.List[double] }
                $byId[$pids[$i]].Add([double]$d)
            }
        }
        $ratios = New-Object System.Collections.Generic.List[double]
        for ($i = 0; $i -lt $ids.Count; $i++) {
            $d = $run.durations[$i]
            if ($null -eq $d -or -not $byId.ContainsKey($ids[$i])) { continue }
            $base = Median ([double[]]$byId[$ids[$i]].ToArray())
            if ($base -gt 0) { $ratios.Add([double]$d / $base) }
        }
        if ($ratios.Count -eq 0) { continue }
        $paceB = Median ([double[]]$ratios.ToArray())
        $failed = ($run.results.ToCharArray() | Where-Object { $_ -eq 'F' }).Count
        [void]$all.Add([pscustomobject]@{ Suite = $key; Run = $run.id; Partial = $run.partial; N = $ids.Count; Failed = $failed; PaceA = [math]::Round($paceA, 2); PaceB = [math]::Round($paceB, 2) })
    }
}

"suites/streams: $($runsBySuite.Keys.Count) · runs measured (>=5 full priors): $($all.Count) · partial among them: $(@($all | Where-Object Partial).Count)"
foreach ($name in 'PaceA', 'PaceB') {
    $v = [double[]]@($all | ForEach-Object { $_.$name })
    "{0}: p05 {1} p50 {2} p90 {3} p95 {4} p99 {5} max {6} | >=1.5: {7}  >=2: {8}  >=3: {9}" -f $name, (Pct $v 0.05), (Pct $v 0.5), (Pct $v 0.9), (Pct $v 0.95), (Pct $v 0.99), ($v | Measure-Object -Maximum).Maximum, @($v | Where-Object { $_ -ge 1.5 }).Count, @($v | Where-Object { $_ -ge 2 }).Count, @($v | Where-Object { $_ -ge 3 }).Count
}
$withFail = @($all | Where-Object { $_.Failed -gt 0 })
"runs with a failure: $($withFail.Count) · of those PaceB>=1.5: $(@($withFail | Where-Object { $_.PaceB -ge 1.5 }).Count) · PaceB>=2: $(@($withFail | Where-Object { $_.PaceB -ge 2 }).Count)"
"largest disagreement between A and B:"
$all | Sort-Object { [math]::Abs($_.PaceA - $_.PaceB) } -Descending | Select-Object -First 6 | Format-Table -AutoSize
"slowest runs by PaceB:"
$all | Sort-Object PaceB -Descending | Select-Object -First 8 | Format-Table -AutoSize
