Evidence for plans/HISTORY_VERDICT_NOISE_PLAN.md, §1.2 and §6.2 (made 2026-09-18/19).

ledger.full-partial-full-contendedA-contendedB-healthy.jsonl
    BreakfastProvider xUnit in-memory suite, suite name xunit3-local: 11 healthy full runs (the seed),
    a full run, a PARTIAL run (-namespace ...Scenarios.Orders, 33 scenarios), a full run, contended
    run A, contended run B, a healthy full run. Replay the last six with LedgerReplayProbe (in the
    prototype patch): REPLAY_LEDGER, REPLAY_OUT, REPLAY_LAST=6, REPLAY_MINRUNS=3, KRONIKOL_HISTORY=off.
ledger.contended-1core-6hogs.jsonl   the seed + partial sequence, then one processor shared with six busy loops
ledger.pinned-*.jsonl                the same, then a run pinned to 8 / 4 / 2 / 1 logical processors with nothing competing
stats.*.csv                          seven candidate "degraded" statistics for every run (REPLAY_STATS=1); stats.ci.csv is BreakfastProvider's CI ledger, 394 runs
starve.ps1, starve2.ps1              how the pinned and the contended runs were made (paths are the author's)
pace.ps1                             the first round's PowerShell reimplementation of pace
