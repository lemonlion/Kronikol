param([string[]]$Labels = @('8core', '4core', '2core', '1core'))

# A full BreakfastProvider run pinned to N logical processors: a degraded run on demand. Each run gets
# its own copy of the healthy ledger, so every one of them is judged against the same baseline.
$sp = 'C:\Users\cex\AppData\Local\Temp\claude\c--Code-BreakfastProvider\fec4b9a0-c909-4998-8933-6fa4d9cbbd5a\scratchpad'
$out = "$sp\degraded"
New-Item -ItemType Directory -Force $out | Out-Null
$exe = 'C:\Code\BreakfastProvider\tests\BreakfastProvider.Tests.Component.xUnit\bin\Debug\net10.0\BreakfastProvider.Tests.Component.xUnit.exe'

# Even-numbered logical processors from 2 up: one hardware thread per core on a hyper-threaded part,
# and not processor 0, which takes the interrupts.
$masks = @{
    '8core' = 0x5554   # 2,4,6,8,10,12,14 + 16? -> see below
    '4core' = 0x0154   # 2,4,6,8
    '2core' = 0x0014   # 2,4
    '1core' = 0x0004   # 2
}
$masks['8core'] = (1 -shl 2) -bor (1 -shl 4) -bor (1 -shl 6) -bor (1 -shl 8) -bor (1 -shl 10) -bor (1 -shl 12) -bor (1 -shl 14) -bor (1 -shl 16)

foreach ($label in $Labels) {
    $ledger = "$out\history.$label.jsonl"
    Copy-Item "$sp\partial\history.full-partial-full.jsonl" $ledger -Force
    $env:KRONIKOL_HISTORY = $ledger
    $log = "$out\run.$label.log"
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $p = Start-Process -FilePath $exe -ArgumentList '-noLogo' -WorkingDirectory (Split-Path $exe) -RedirectStandardOutput $log -RedirectStandardError "$log.err" -PassThru -WindowStyle Hidden
    $p.ProcessorAffinity = [IntPtr]$masks[$label]
    $p.WaitForExit()
    $watch.Stop()
    $summary = Get-Content $log | Where-Object { $_ -match 'Total: \d+' } | Select-Object -Last 1
    "{0}: mask=0x{1:X} exit={2} wall={3:N0}s :: {4}" -f $label, $masks[$label], $p.ExitCode, $watch.Elapsed.TotalSeconds, $summary
}
