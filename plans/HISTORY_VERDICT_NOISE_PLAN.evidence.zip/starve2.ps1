param([string]$Label, [int[]]$Processors, [int]$HogsPerProcessor, [string]$Seed = 'partial\history.full-partial-full.jsonl')

# A full BreakfastProvider run pinned to a few logical processors that are ALSO kept busy by CPU hogs
# pinned to the same processors, at normal priority: a noisy neighbour on a CI agent. The rest of the
# machine is left alone.
$sp = 'C:\Users\cex\AppData\Local\Temp\claude\c--Code-BreakfastProvider\fec4b9a0-c909-4998-8933-6fa4d9cbbd5a\scratchpad'
$out = "$sp\degraded"
New-Item -ItemType Directory -Force $out | Out-Null
$exe = 'C:\Code\BreakfastProvider\tests\BreakfastProvider.Tests.Component.xUnit\bin\Debug\net10.0\BreakfastProvider.Tests.Component.xUnit.exe'

$mask = 0
foreach ($lp in $Processors) { $mask = $mask -bor (1 -shl $lp) }
$ledger = "$out\history.$Label.jsonl"
Copy-Item "$sp\$Seed" $ledger -Force
$env:KRONIKOL_HISTORY = $ledger
$log = "$out\run.$Label.log"

$hogs = @()
try {
    foreach ($lp in $Processors) {
        for ($h = 0; $h -lt $HogsPerProcessor; $h++) {
            $hog = Start-Process -FilePath 'pwsh' -ArgumentList '-NoProfile', '-NonInteractive', '-Command', 'while ($true) { }' -PassThru -WindowStyle Hidden
            $hog.ProcessorAffinity = [IntPtr](1 -shl $lp)
            $hogs += $hog
        }
    }
    Start-Sleep -Seconds 2
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $p = Start-Process -FilePath $exe -ArgumentList '-noLogo' -WorkingDirectory (Split-Path $exe) -RedirectStandardOutput $log -RedirectStandardError "$log.err" -PassThru -WindowStyle Hidden
    $p.ProcessorAffinity = [IntPtr]$mask
    $p.WaitForExit()
    $watch.Stop()
    $summary = Get-Content $log | Where-Object { $_ -match 'Total: \d+' } | Select-Object -Last 1
    "{0}: mask=0x{1:X} hogs={2} exit={3} wall={4:N0}s :: {5}" -f $Label, $mask, $hogs.Count, $p.ExitCode, $watch.Elapsed.TotalSeconds, $summary
}
finally {
    foreach ($hog in $hogs) { try { if (-not $hog.HasExited) { $hog.Kill() } } catch { } }
}
